package com.example.mylatop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NenDangNhap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nen_dang_nhap);
    }
}
